#!/bin/bash
# validate_survey.sh - Validate survey CSV files for common data quality issues
# Usage: bash validate_survey.sh <file.csv>
#
# This script checks:
# 1. File exists and is readable
# 2. Header row matches expected columns
# 3. Reports total row count (excluding header)
# 4. Counts rows with missing required fields (hhid, consent)

# Expected header (first row of valid files)
EXPECTED_HEADER="hhid,survey_date,village,treatment_arm,consent,age,education_years"

# Check for correct number of arguments
if [ $# -ne 1 ]; then
    echo "Usage: bash validate_survey.sh <file.csv>"
    exit 1
fi

FILE="$1"

# Check if file exists
if [ ! -f "$FILE" ]; then
    echo "ERROR: File not found: $FILE"
    exit 2
fi

echo "Validating: $FILE"
echo "----------------------------------------"

# Check header
HEADER=$(head -n 1 "$FILE")
if [ "$HEADER" = "$EXPECTED_HEADER" ]; then
    echo "[PASS] Header matches expected columns"
else
    echo "[FAIL] Header mismatch"
    echo "  Expected: $EXPECTED_HEADER"
    echo "  Found:    $HEADER"
fi

# Count total rows (excluding header)
TOTAL_ROWS=$(tail -n +2 "$FILE" | wc -l)
echo "[INFO] Total records: $TOTAL_ROWS"

# Count rows with missing hhid (first field empty)
MISSING_HHID=$(tail -n +2 "$FILE" | cut -d',' -f1 | grep -c "^$")
if [ "$MISSING_HHID" -gt 0 ]; then
    echo "[FAIL] Missing hhid: $MISSING_HHID rows"
else
    echo "[PASS] All rows have hhid"
fi

# Count rows with missing consent (5th field empty)
MISSING_CONSENT=$(tail -n +2 "$FILE" | cut -d',' -f5 | grep -c "^$")
if [ "$MISSING_CONSENT" -gt 0 ]; then
    echo "[FAIL] Missing consent: $MISSING_CONSENT rows"
else
    echo "[PASS] All rows have consent"
fi

echo "----------------------------------------"

# Summary
if [ "$MISSING_HHID" -eq 0 ] && [ "$MISSING_CONSENT" -eq 0 ] && [ "$HEADER" = "$EXPECTED_HEADER" ]; then
    echo "RESULT: PASS - File is valid"
    exit 0
else
    echo "RESULT: FAIL - File has validation errors"
    exit 1
fi
