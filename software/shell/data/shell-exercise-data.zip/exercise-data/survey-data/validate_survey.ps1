# validate_survey.ps1 - Validate survey CSV files for common data quality issues
# Usage: .\validate_survey.ps1 <file.csv>
#
# This script checks:
# 1. File exists and is readable
# 2. Header row matches expected columns
# 3. Reports total row count (excluding header)
# 4. Counts rows with missing required fields (hhid, consent)

param(
    [Parameter(Mandatory=$true, Position=0)]
    [string]$File
)

# Expected header (first row of valid files)
$ExpectedHeader = "hhid,survey_date,village,treatment_arm,consent,age,education_years"

# Check if file exists
if (-not (Test-Path $File)) {
    Write-Host "ERROR: File not found: $File" -ForegroundColor Red
    exit 2
}

Write-Host "Validating: $File"
Write-Host "----------------------------------------"

# Read file content
$Content = Get-Content $File
$Header = $Content[0]
$DataRows = $Content | Select-Object -Skip 1

# Check header
if ($Header -eq $ExpectedHeader) {
    Write-Host "[PASS] Header matches expected columns" -ForegroundColor Green
} else {
    Write-Host "[FAIL] Header mismatch" -ForegroundColor Red
    Write-Host "  Expected: $ExpectedHeader"
    Write-Host "  Found:    $Header"
}

# Count total rows
$TotalRows = $DataRows.Count
Write-Host "[INFO] Total records: $TotalRows"

# Count rows with missing hhid (first field empty)
$MissingHhid = 0
$MissingConsent = 0

foreach ($Row in $DataRows) {
    $Fields = $Row -split ','
    if ([string]::IsNullOrEmpty($Fields[0])) {
        $MissingHhid++
    }
    if ($Fields.Count -ge 5 -and [string]::IsNullOrEmpty($Fields[4])) {
        $MissingConsent++
    }
}

if ($MissingHhid -gt 0) {
    Write-Host "[FAIL] Missing hhid: $MissingHhid rows" -ForegroundColor Red
} else {
    Write-Host "[PASS] All rows have hhid" -ForegroundColor Green
}

if ($MissingConsent -gt 0) {
    Write-Host "[FAIL] Missing consent: $MissingConsent rows" -ForegroundColor Red
} else {
    Write-Host "[PASS] All rows have consent" -ForegroundColor Green
}

Write-Host "----------------------------------------"

# Summary
if ($MissingHhid -eq 0 -and $MissingConsent -eq 0 -and $Header -eq $ExpectedHeader) {
    Write-Host "RESULT: PASS - File is valid" -ForegroundColor Green
    exit 0
} else {
    Write-Host "RESULT: FAIL - File has validation errors" -ForegroundColor Red
    exit 1
}
