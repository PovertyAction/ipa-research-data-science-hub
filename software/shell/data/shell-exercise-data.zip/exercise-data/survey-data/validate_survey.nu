# validate_survey.nu - Validate survey CSV files for common data quality issues
# Usage: nu validate_survey.nu <file.csv>
#
# This script checks:
# 1. File exists and is readable
# 2. Header row matches expected columns
# 3. Reports total row count (excluding header)
# 4. Counts rows with missing required fields (hhid, consent)

def main [file: string] {
    # Expected header columns
    let expected_columns = ["hhid", "survey_date", "village", "treatment_arm", "consent", "age", "education_years"]

    # Check if file exists
    if not ($file | path exists) {
        print $"ERROR: File not found: ($file)"
        exit 2
    }

    print $"Validating: ($file)"
    print "----------------------------------------"

    # Read the CSV file
    let data = open $file

    # Check header by comparing column names
    let actual_columns = $data | columns
    let header_match = $actual_columns == $expected_columns

    if $header_match {
        print "[PASS] Header matches expected columns"
    } else {
        print "[FAIL] Header mismatch"
        print $"  Expected: ($expected_columns | str join ',')"
        print $"  Found:    ($actual_columns | str join ',')"
    }

    # Count total rows
    let total_rows = $data | length
    print $"[INFO] Total records: ($total_rows)"

    # Count rows with missing hhid
    let missing_hhid = $data | where { |row| ($row.hhid | is-empty) or ($row.hhid | into string | str trim | is-empty) } | length

    if $missing_hhid > 0 {
        print $"[FAIL] Missing hhid: ($missing_hhid) rows"
    } else {
        print "[PASS] All rows have hhid"
    }

    # Count rows with missing consent
    let missing_consent = $data | where { |row| ($row.consent | is-empty) or ($row.consent | into string | str trim | is-empty) } | length

    if $missing_consent > 0 {
        print $"[FAIL] Missing consent: ($missing_consent) rows"
    } else {
        print "[PASS] All rows have consent"
    }

    print "----------------------------------------"

    # Summary
    if $missing_hhid == 0 and $missing_consent == 0 and $header_match {
        print "RESULT: PASS - File is valid"
        exit 0
    } else {
        print "RESULT: FAIL - File has validation errors"
        exit 1
    }
}
